package training.dao;

import java.sql.SQLException;
import java.util.List;

import training.model.Employee;

public interface EmployeeDAO {
	
	List<Employee> getAll() throws SQLException;
	
	void insert()  throws SQLException;
	
	void delete() throws SQLException;
	
	void update() throws SQLException;
}
