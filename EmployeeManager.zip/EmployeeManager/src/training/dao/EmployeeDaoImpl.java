package training.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import training.model.Employee;
import training.util.DBUtils;
import training.util.SQLCommand;

public class EmployeeDaoImpl implements EmployeeDAO {

	private Connection connection;
	private PreparedStatement preparedStatement = null;
	private CallableStatement caStatement = null;
	private ResultSet results = null;

	@Override
	public List<Employee> getAll() throws SQLException {
		List<Employee> Emps = new ArrayList<>();
		Employee emp = null;
		try {
			connection = DBUtils.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(SQLCommand.EMPLOYEE_QUERY_FIND_ALL);
			results = preparedStatement.executeQuery();
			while (results.next()) {
				emp = new Employee();
				emp.setUserName(results.getString("UserName"));
				emp.setFullName(results.getString("FullName"));
				emp.setPhone(results.getInt("phone"));
				Emps.add(emp);
			}
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}

				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return Emps;
		}

	}

	@Override
	public void insert() throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Input username");
		String userName = sc.nextLine();
		System.out.println("Input fullname");
		String fullName = sc.nextLine();
		System.out.println("Input phone");
		int phone = Integer.parseInt(sc.nextLine());

		try {
			connection = DBUtils.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(SQLCommand.EMPLOYEE_INSERT);
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, fullName);
			preparedStatement.setInt(3, phone);
			preparedStatement.executeUpdate();

		} finally {
			try {
				if (connection != null) {
					connection.close();
				}

				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		

	}

	@Override
	public void delete() throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Input username to delete");
		String userName = sc.nextLine();
		try {
			connection = DBUtils.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(SQLCommand.EMPLOYEE_DELETE);
			preparedStatement.setString(1, userName);
			preparedStatement.executeUpdate();

		} finally {
			try {
				if (connection != null) {
					connection.close();
				}

				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		

	}

	@Override
	public void update() throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Input username to update");
		String userName = sc.nextLine();

		System.out.println("Input new fullName: ");
		String fullName = sc.nextLine();

		System.out.println("Input new phone: ");
		int phone = Integer.parseInt(sc.nextLine());
		try {
			connection = DBUtils.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(SQLCommand.EMPLOYEE_UPDATE);
			preparedStatement.setString(1, fullName);
			preparedStatement.setInt(2, phone);
			preparedStatement.setString(3, userName);
			preparedStatement.executeUpdate();

		} finally {
			try {
				if (connection != null) {
					connection.close();
				}

				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		

	}

}
