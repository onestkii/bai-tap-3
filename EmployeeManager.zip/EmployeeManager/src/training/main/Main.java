package training.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import training.dao.EmployeeDAO;
import training.dao.EmployeeDaoImpl;
import training.model.Employee;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String x = null;
		

		EmployeeDAO employeeDAO = new EmployeeDaoImpl();

		do {
			System.out.println("__________OPTION__________");
			System.out.println("1.Display");
			System.out.println("2.Insert");
			System.out.println("3.Delete");
			System.out.println("4.Update");
			System.out.println("5.Exit");
			System.out.println("Input option: ");
			x = sc.nextLine();

			switch (x) {
			case "1":
				try {
					List<Employee> emps = employeeDAO.getAll();
					for (Employee e : emps) {
						System.out.println(e);
					}
				} catch (SQLException e) {
					System.out.println("Display fail");
				}
				break;
			case "2":
				try {
					employeeDAO.insert();
				} catch (SQLException e) {
					System.out.println("insert fail");
				}
				break;
			case "3":
				try {
					employeeDAO.delete();
				} catch (SQLException e) {
					System.out.println("delete fail");
				}
				break;
			case "4":
				try {
					employeeDAO.update();
				} catch (SQLException e) {
					System.out.println("update fail");
				}
				break;
			case "5":
				System.exit(0);
				break;
			}

		} while (true);
	}
}
