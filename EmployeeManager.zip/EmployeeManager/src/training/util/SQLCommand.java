package training.util;

public class SQLCommand {

	public static String EMPLOYEE_QUERY_FIND_ALL = "SELECT * from employee";
	public static String EMPLOYEE_INSERT = "INSERT INTO EMPLOYEE VALUES (?,?,?)";
	public static String EMPLOYEE_DELETE = "DELETE FROM EMPLOYEE WHERE USERNAME = ?";
	public static String EMPLOYEE_UPDATE = "UPDATE EMPLOYEE SET FULLNAME = ?, PHONE = ?  WHERE USERNAME = ?";

}
